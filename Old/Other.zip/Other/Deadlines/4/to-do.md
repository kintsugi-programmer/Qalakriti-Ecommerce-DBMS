Write and execute TEN SQL queries about your application involving various relational algebraic operations supporting the application features involving database access and manipulation.

Requirements:

Diverse queries containing various select, update, etc. commands.
Showcase adequate relational algebraic operations.
Showcase your constraints
A document containing your relational schema.

Your must submit a text file containing SQL queries and the document.